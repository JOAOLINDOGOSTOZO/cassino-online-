const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const port = process.env.PORT || 10000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/games', express.static(path.join(__dirname, 'games')));
app.use('/admin', express.static(path.join(__dirname, 'admin')));

const db = new sqlite3.Database('./db.sqlite');

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS ranking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT,
    saldo INTEGER
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS relatorio (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    data TEXT,
    jogador TEXT,
    resultado TEXT,
    saldoAntes INTEGER,
    saldoDepois INTEGER
  )`);
});

app.get('/ranking', (req, res) => {
  db.all("SELECT * FROM ranking ORDER BY saldo DESC", (err, rows) => {
    res.json(rows);
  });
});

app.post('/ranking', (req, res) => {
  const { nome, saldo } = req.body;
  db.get("SELECT * FROM ranking WHERE nome = ?", [nome], (err, row) => {
    if (row) {
      db.run("UPDATE ranking SET saldo = ? WHERE nome = ?", [saldo, nome]);
    } else {
      db.run("INSERT INTO ranking (nome, saldo) VALUES (?, ?)", [nome, saldo]);
    }
    res.json({ status: "OK" });
  });
});

app.delete('/ranking', (req, res) => {
  db.run("DELETE FROM ranking", () => {
    res.json({ status: "Ranking limpo" });
  });
});

app.get('/relatorio', (req, res) => {
  db.all("SELECT * FROM relatorio ORDER BY id DESC", (err, rows) => {
    res.json(rows);
  });
});

app.post('/relatorio', (req, res) => {
  const { data, jogador, resultado, saldoAntes, saldoDepois } = req.body;
  db.run("INSERT INTO relatorio (data, jogador, resultado, saldoAntes, saldoDepois) VALUES (?, ?, ?, ?, ?)",
    [data, jogador, resultado, saldoAntes, saldoDepois], () => {
      res.json({ status: "OK" });
    });
});

app.delete('/relatorio', (req, res) => {
  db.run("DELETE FROM relatorio", () => {
    res.json({ status: "Relatório limpo" });
  });
});

app.listen(port, () => {
  console.log(`Cassino server rodando na porta ${port}`);
});
